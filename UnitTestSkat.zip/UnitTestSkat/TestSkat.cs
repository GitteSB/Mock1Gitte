using Microsoft.VisualStudio.TestTools.UnitTesting;
using Skat;
using System;


namespace UnitTestSkat
{
    [TestClass]
    public class TestSkat
    {
        [TestMethod]
        public void TestAfNegativtTal()
        {
            //Arrange
            int pris = -50000;
            // Act
            try
            {
                Afgift.bilAfgift(pris);
            }

            catch (System.Exception e)
            {
                //Assert
                Assert.AreEqual("Du har tastet et negativt tal ind, Prisen kan ikke v�re mindre end 0", e.Message);
            }
        }

        [TestMethod]
        public void TestAfMiddelPris()
        {
            //Arrange
            int pris = 100000;
            //Act
            try
            {
                Afgift.bilAfgift(pris);

            }
            catch (Exception e)
            {

                //Assert
                Assert.AreEqual("Du har k�bt en middelprisbil", e.Message);

            }
        }
        [TestMethod]
        public void TestAfH�jPris()
        {
            //Arrange
            int pris = 2000000;


            try
            {
                //Act   
                Afgift.bilAfgift(pris);

            }
            catch (Exception e)
            {
                //Assert
                Assert.AreEqual("Du har tastet en meget h�j pris ind", e.Message);
            }
        }

        public void TestAfNegativtTalElBil()
        {
            //Arrange
            int pris = -50000;
            // Act
            try
            {
                Afgift.elBilAfgift(pris);
            }

            catch (System.Exception e)
            {
                //Assert
                Assert.AreEqual("Du har tastet et negativt tal ind, Prisen kan ikke v�re mindre end 0", e.Message);
            }
        }

        [TestMethod]
        public void TestAfMiddelPrisElBil()
        {
            //Arrange
            int pris = 100000;
            //Act
            try
            {
                Afgift.elBilAfgift(pris);

            }
            catch (Exception e)
            {

                //Assert
                Assert.AreEqual("Du har k�bt en middelprisbil", e.Message);

            }
        }
        [TestMethod]
        public void TestAfH�jPrisElBil()
        {
            //Arrange
            int pris = 2000000;


            try
            {
                //Act   
                Afgift.elBilAfgift(pris);

            }
            catch (Exception e)
            {
                //Assert
                Assert.AreEqual("Du har tastet en meget h�j pris ind", e.Message);
            }
        }





    }
}

  
    



